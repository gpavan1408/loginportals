<?php

    $con = mysqli_connect("localhost","root","france@143","fastenmedia");
    if ($con->connect_error) {
        die('Connect Error: ' . $con->connect_error);
    }
?>